import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import PainPoints from './components/PainPoints';
import Services from './components/Services';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { HERO_IMAGE, ABOUT_IMAGE, PORTFOLIO_VIDEO } from './constants';

function App() {
  // Bumping to _v12 to ensure the new HERO_IMAGE constant (m1.png) is prioritized over old cached links
  const [heroImage, setHeroImage] = useState<string>(() => {
    return localStorage.getItem('portfolio_hero_image_v12') || HERO_IMAGE;
  });

  const [aboutImage, setAboutImage] = useState<string>(() => {
    return localStorage.getItem('portfolio_about_image_v12') || ABOUT_IMAGE;
  });

  const [dashboardVideo, setDashboardVideo] = useState<string | null>(PORTFOLIO_VIDEO);

  const handleHeroImageUpdate = (newSrc: string) => {
    setHeroImage(newSrc);
    try {
      if (newSrc.startsWith('data:')) {
        localStorage.setItem('portfolio_hero_image_v12', newSrc);
      } else {
        localStorage.removeItem('portfolio_hero_image_v12');
      }
    } catch (error) {
      console.warn('Image too large to save to local storage');
    }
  };

  const handleAboutImageUpdate = (newSrc: string) => {
    setAboutImage(newSrc);
    try {
      if (newSrc.startsWith('data:')) {
        localStorage.setItem('portfolio_about_image_v12', newSrc);
      } else {
        localStorage.removeItem('portfolio_about_image_v12');
      }
    } catch (error) {
      console.warn('Image too large to save to local storage');
    }
  };

  return (
    <div className="min-h-screen font-sans selection:bg-brand-sage selection:text-brand-dark">
      <Navbar />
      <main>
        <Hero 
          imageSrc={heroImage} 
          setImageSrc={handleHeroImageUpdate} 
        />
        <PainPoints />
        <Services 
          videoSrc={dashboardVideo}
          setVideoSrc={setDashboardVideo}
        />
        <About 
          imageSrc={aboutImage} 
          setImageSrc={handleAboutImageUpdate} 
        />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;