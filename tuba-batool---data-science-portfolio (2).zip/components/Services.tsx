import React, { useRef, useState, useEffect } from 'react';
import { LayoutDashboard, BrainCircuit, Search, Rocket, Upload, BarChart, Loader2 } from 'lucide-react';

interface ServicesProps {
  videoSrc: string | null;
  setVideoSrc: (src: string) => void;
}

const Services: React.FC<ServicesProps> = ({ videoSrc, setVideoSrc }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  // Initialize loading to true if there is a video source to load
  const [loading, setLoading] = useState(!!videoSrc);

  // If videoSrc changes externally (or is set to null), update loading state logic
  useEffect(() => {
    if (!videoSrc) {
      setLoading(false);
    } else {
      setLoading(true);
    }
  }, [videoSrc]);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLoading(true);
      const videoUrl = URL.createObjectURL(file);
      setVideoSrc(videoUrl);
    }
  };

  const handleMediaLoad = () => {
    setLoading(false);
  };

  const isGoogleDrive = videoSrc?.includes('drive.google.com');

  return (
    <section id="portfolio" className="py-20 bg-white relative overflow-hidden scroll-mt-24">
      {/* Subtle background pattern */}
      <div className="absolute top-0 left-0 w-full h-full opacity-30 pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-brand-sageLight/40 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-brand-accent/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div className="order-2 lg:order-1">
            <h2 className="font-serif text-4xl lg:text-5xl font-bold text-brand-dark mb-6">
              Portfolio & Expertise: <span className="text-brand-sageDark">Data Solutions</span>
            </h2>
            <p className="text-slate-700 text-lg mb-8 leading-relaxed font-medium">
              I help businesses unlock the true potential of their data. From exploratory analysis and machine learning model development to full-scale deployment and interactive reporting.
            </p>
            
            <div className="space-y-6">
              {/* Service 1: Machine Learning */}
              <div className="flex gap-4 p-4 rounded-xl hover:bg-brand-cream/50 transition-colors duration-300">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-brand-dark text-white rounded-lg flex items-center justify-center">
                    <BrainCircuit size={24} />
                  </div>
                </div>
                <div>
                  <h3 className="font-bold text-xl text-brand-dark">Machine Learning Solutions</h3>
                  <p className="text-slate-700 mt-1 font-medium">
                    Developing custom predictive models (Regression, Classification, Clustering) to forecast trends and automate complex decision-making processes.
                  </p>
                </div>
              </div>

              {/* Service 2: Data Analysis */}
              <div className="flex gap-4 p-4 rounded-xl hover:bg-brand-cream/50 transition-colors duration-300">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-brand-sageDark text-white rounded-lg flex items-center justify-center">
                    <Search size={24} />
                  </div>
                </div>
                <div>
                  <h3 className="font-bold text-xl text-brand-dark">Advanced Data Analysis</h3>
                  <p className="text-slate-700 mt-1 font-medium">
                    Deep-dive exploratory data analysis (EDA) using Python (Pandas, NumPy) to uncover hidden patterns, correlations, and actionable insights.
                  </p>
                </div>
              </div>

              {/* Service 3: Model Deployment */}
              <div className="flex gap-4 p-4 rounded-xl hover:bg-brand-cream/50 transition-colors duration-300">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-brand-accent text-brand-dark rounded-lg flex items-center justify-center">
                    <Rocket size={24} />
                  </div>
                </div>
                <div>
                  <h3 className="font-bold text-xl text-brand-dark">Model Deployment (MLOps)</h3>
                  <p className="text-slate-700 mt-1 font-medium">
                    Deploying models into production environments. Building scalable APIs (FastAPI, Flask) and integrating with cloud services.
                  </p>
                </div>
              </div>

              {/* Service 4: Power BI */}
              <div className="flex gap-4 p-4 rounded-xl hover:bg-brand-cream/50 transition-colors duration-300">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-brand-sageLight text-brand-dark rounded-lg flex items-center justify-center">
                    <LayoutDashboard size={24} />
                  </div>
                </div>
                <div>
                  <h3 className="font-bold text-xl text-brand-dark">Power BI Dashboards</h3>
                  <p className="text-slate-700 mt-1 font-medium">
                    Transforming data into storytelling. Creating interactive, real-time Power BI dashboards for strategic business monitoring.
                  </p>
                </div>
              </div>

            </div>
          </div>

          <div className="order-1 lg:order-2 relative group">
             {/* Video Player Container */}
            <div className="bg-brand-dark rounded-2xl overflow-hidden shadow-2xl relative z-10 border border-gray-700 aspect-video flex items-center justify-center bg-gray-900">
               
               {/* Loading Overlay */}
               {loading && videoSrc && (
                 <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-gray-900/90 backdrop-blur-sm">
                   <Loader2 className="w-10 h-10 text-brand-sage animate-spin mb-3" />
                   <p className="text-brand-sageLight font-medium animate-pulse">Loading Video...</p>
                 </div>
               )}

               {videoSrc ? (
                   isGoogleDrive ? (
                     <iframe 
                       src={videoSrc}
                       className="w-full h-full border-none"
                       allow="autoplay; fullscreen"
                       title="Portfolio Project"
                       onLoad={handleMediaLoad}
                     ></iframe>
                   ) : (
                     <video 
                       src={videoSrc} 
                       className="w-full h-full object-cover" 
                       controls 
                       autoPlay 
                       muted 
                       loop 
                       playsInline
                       onLoadedData={handleMediaLoad}
                     />
                   )
               ) : (
                   <div className="text-center p-8">
                       <div className="w-20 h-20 bg-brand-sage/20 rounded-full flex items-center justify-center mx-auto mb-6 text-brand-sage animate-pulse">
                           <BarChart fill="currentColor" size={40} className="ml-1" />
                       </div>
                       <h3 className="text-white font-serif text-xl mb-2">Power BI Dashboard MCP</h3>
                       <p className="text-brand-sageLight font-medium">Interactive Data Visualization</p>
                       <p className="text-gray-500 text-sm mt-2">Click to upload dashboard demo video</p>
                   </div>
               )}
               
               {/* Upload Button Overlay */}
               <button 
                   onClick={() => fileInputRef.current?.click()}
                   disabled={loading}
                   className={`absolute top-4 right-4 bg-black/40 hover:bg-black/60 backdrop-blur-md text-white px-3 py-2 rounded-lg transition-all flex items-center gap-2 text-sm font-medium border border-white/20 hover:border-brand-sage ${
                     loading ? 'opacity-50 cursor-not-allowed' : ''
                   }`}
                   title={loading ? "Video is loading..." : "Upload a local video"}
               >
                   <Upload size={16} />
                   <span>{loading ? 'Loading...' : 'Replace Video'}</span>
               </button>
               <input 
                   type="file" 
                   ref={fileInputRef}
                   className="hidden" 
                   accept="video/*" 
                   onChange={handleVideoUpload}
               />
            </div>
            
            {/* Background blobs */}
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-brand-sage/10 rounded-full blur-3xl"></div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Services;