import React, { useState } from 'react';
import { Mail, Calendar, Linkedin, AlertCircle } from 'lucide-react';
import { CONTACT_EMAIL, LINKEDIN_URL } from '../constants';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const [errors, setErrors] = useState({
    name: '',
    email: '',
    message: ''
  });

  const [touched, setTouched] = useState({
    name: false,
    email: false,
    message: false
  });

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors = {
      name: !formData.name.trim() ? 'Name is required' : '',
      email: !formData.email.trim() ? 'Email is required' : (!validateEmail(formData.email) ? 'Please enter a valid email address' : ''),
      message: !formData.message.trim() ? 'Message is required' : ''
    };

    setErrors(newErrors);
    setTouched({ name: true, email: true, message: true });

    if (!newErrors.name && !newErrors.email && !newErrors.message) {
      // Construct mailto link
      const subject = encodeURIComponent(`New Inquiry from ${formData.name}`);
      const body = encodeURIComponent(`Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`);
      window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
      
      // Reset form
      setFormData({ name: '', email: '', message: '' });
      setTouched({ name: false, email: false, message: false });
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;

    // Strict input for name: only allow letters and spaces
    if (name === 'name' && !/^[a-zA-Z\s]*$/.test(value)) {
      return;
    }

    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear error when user starts typing if field was previously errored
    if (errors[name as keyof typeof errors]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setTouched(prev => ({ ...prev, [name]: true }));
    
    let errorMessage = '';
    if (name === 'name' && !value.trim()) errorMessage = 'Name is required';
    if (name === 'email') {
        if (!value.trim()) errorMessage = 'Email is required';
        else if (!validateEmail(value)) errorMessage = 'Please enter a valid email address';
    }
    if (name === 'message' && !value.trim()) errorMessage = 'Message is required';
    
    setErrors(prev => ({ ...prev, [name]: errorMessage }));
  };

  return (
    <section id="contact" className="py-20 bg-brand-dark text-white relative overflow-hidden">
      {/* Background circles */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-brand-sage/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-sage/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl font-bold mb-4">Let's Solve Your Data Puzzle</h2>
          <p className="text-brand-sageLight max-w-2xl mx-auto text-lg">
            Ready to stop guessing and start knowing? I'm currently accepting new projects. 
            Tell me about your biggest data headache.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Contact Info */}
          <div className="space-y-8 bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm">
            <h3 className="text-2xl font-serif font-bold">Get in Touch</h3>
            
            <div className="flex items-start gap-4">
              <div className="p-3 bg-brand-sage rounded-lg text-brand-dark">
                <Mail size={24} />
              </div>
              <div>
                <h4 className="font-bold text-lg">Email Me</h4>
                <p className="text-brand-sageLight text-sm mb-1">Best for project inquiries</p>
                <a href={`mailto:${CONTACT_EMAIL}`} className="hover:text-brand-sage transition-colors">{CONTACT_EMAIL}</a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 bg-brand-sage rounded-lg text-brand-dark">
                <Linkedin size={24} />
              </div>
              <div>
                <h4 className="font-bold text-lg">LinkedIn</h4>
                <p className="text-brand-sageLight text-sm mb-1">Let's connect professionally</p>
                <a href={LINKEDIN_URL} target="_blank" rel="noopener noreferrer" className="hover:text-brand-sage transition-colors">
                  {LINKEDIN_URL.replace('https://www.', '').replace('https://', '')}
                </a>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-white/10">
                <p className="italic text-brand-sageLight">
                    "Tuba transformed our quarterly reporting from a 3-day headache into a 5-minute refresh. The Python script she wrote is a lifesaver!"
                </p>
                <p className="font-bold mt-2">- Previous Client</p>
            </div>
          </div>

          {/* Contact Form */}
          <form className="space-y-6" onSubmit={handleSubmit} noValidate>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-brand-sageLight mb-2">Name</label>
                <div className="relative">
                  <input 
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    required
                    className={`w-full px-4 py-3 bg-white/10 border rounded-lg focus:outline-none focus:border-brand-sage text-white placeholder-gray-400 transition-colors ${errors.name ? 'border-red-500' : 'border-white/20'}`}
                    placeholder="John Doe" 
                  />
                  {errors.name && (
                    <div className="absolute right-3 top-3.5 text-red-500">
                      <AlertCircle size={18} />
                    </div>
                  )}
                </div>
                {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-brand-sageLight mb-2">Email</label>
                <div className="relative">
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    required
                    className={`w-full px-4 py-3 bg-white/10 border rounded-lg focus:outline-none focus:border-brand-sage text-white placeholder-gray-400 transition-colors ${errors.email ? 'border-red-500' : 'border-white/20'}`}
                    placeholder="john@company.com" 
                  />
                  {errors.email && (
                    <div className="absolute right-3 top-3.5 text-red-500">
                      <AlertCircle size={18} />
                    </div>
                  )}
                </div>
                {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-brand-sageLight mb-2">What's your biggest data challenge?</label>
              <div className="relative">
                <textarea 
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  required
                  rows={4} 
                  className={`w-full px-4 py-3 bg-white/10 border rounded-lg focus:outline-none focus:border-brand-sage text-white placeholder-gray-400 transition-colors ${errors.message ? 'border-red-500' : 'border-white/20'}`}
                  placeholder="e.g. My Excel sheets are too slow..."
                ></textarea>
                {errors.message && (
                  <div className="absolute right-3 top-3.5 text-red-500">
                    <AlertCircle size={18} />
                  </div>
                )}
              </div>
              {errors.message && <p className="text-red-400 text-xs mt-1">{errors.message}</p>}
            </div>

            <button type="submit" className="w-full py-4 bg-brand-sage text-brand-dark font-bold rounded-lg hover:bg-white transition-all duration-300 shadow-lg flex items-center justify-center gap-2">
              <Calendar size={20} />
              Book a Free Consultation
            </button>
          </form>

        </div>
      </div>
    </section>
  );
};

export default Contact;