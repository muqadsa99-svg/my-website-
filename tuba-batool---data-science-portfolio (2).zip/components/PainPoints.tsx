import React from 'react';
    import { Frown, FileQuestion, TrendingDown, ArrowDown } from 'lucide-react';
    
    const PainPoints: React.FC = () => {
      const pains = [
        {
          icon: <FileQuestion className="w-10 h-10 text-red-500" />,
          title: "The Spreadsheet Nightmare",
          desc: "Are you drowning in endless Excel sheets that crash, contain errors, and take hours to update manually every week?",
          solution: "Automated Pipelines"
        },
        {
          icon: <TrendingDown className="w-10 h-10 text-orange-500" />,
          title: "The 'What Happened?' Syndrome",
          desc: "You see sales dropping or costs rising, but you can't pinpoint WHY it's happening until it's too late to fix it.",
          solution: "Real-time Diagnostics"
        },
        {
          icon: <Frown className="w-10 h-10 text-slate-500" />,
          title: "Decision Paralysis",
          desc: "You have plenty of data, but it's not telling a story. You're guessing instead of knowing, leaving money on the table.",
          solution: "Actionable Storytelling"
        }
      ];
    
      return (
        <section id="problems" className="py-20 bg-brand-cream relative">
            {/* Diagonal Divider */}
            <div className="absolute top-0 left-0 w-full overflow-hidden leading-none rotate-180">
                <svg className="relative block w-[calc(100%+1.3px)] h-[50px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                    <path d="M1200 120L0 16.48 0 0 1200 0 1200 120z" className="fill-white"></path>
                </svg>
            </div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-serif text-4xl font-bold text-brand-dark mb-4">Does this sound familiar?</h2>
              <p className="text-slate-700 max-w-2xl mx-auto text-lg font-medium">
                Most businesses fail not because they lack data, but because they lack clarity. I solve the problems that keep you up at night.
              </p>
            </div>
    
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {pains.map((pain, index) => (
                <div key={index} className="bg-white p-8 rounded-2xl shadow-sm border border-brand-sageLight hover:shadow-md transition-shadow duration-300 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-brand-sage/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-150 duration-500"></div>
                  
                  <div className="mb-6 bg-brand-cream w-16 h-16 rounded-full flex items-center justify-center">
                    {pain.icon}
                  </div>
                  
                  <h3 className="font-serif text-xl font-bold text-brand-dark mb-3">{pain.title}</h3>
                  <p className="text-slate-700 mb-6 leading-relaxed font-medium">
                    {pain.desc}
                  </p>
                  
                  <div className="flex items-center text-brand-dark font-bold text-sm">
                    <span className="uppercase tracking-wider">Solution: {pain.solution}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-center mt-12">
                <ArrowDown className="text-brand-sageDark animate-bounce w-8 h-8" />
            </div>
          </div>
        </section>
      );
    };
    
    export default PainPoints;