import React from 'react';
import { CheckCircle2, Camera } from 'lucide-react';
import { OWNER_NAME, OWNER_ROLE } from '../constants';

interface AboutProps {
    imageSrc: string;
    setImageSrc: (src: string) => void;
}

const About: React.FC<AboutProps> = ({ imageSrc, setImageSrc }) => {
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          // Create a canvas to resize the image
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          // Max width 800px to ensure it fits in localStorage
          const MAX_WIDTH = 800;
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            // Compress to JPEG at 0.7 quality
            const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
            setImageSrc(dataUrl);
          }
        };
        if (event.target?.result) {
          img.src = event.target.result as string;
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="about" className="py-20 bg-brand-sageLight/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col-reverse lg:flex-row gap-12 items-center">
            
           {/* Image Container */}
           <div className="w-full lg:w-1/2">
             <div className="relative mx-auto max-w-sm lg:max-w-md group">
                <div className="absolute inset-0 bg-brand-dark/5 transform translate-x-4 translate-y-4 rounded-xl"></div>
                
                <div className="relative rounded-xl overflow-hidden shadow-lg w-full aspect-[3/4]">
                    <img 
                        src={imageSrc} 
                        alt={`${OWNER_NAME} analyzing data`} 
                        className="w-full h-full object-cover"
                        onError={() => {
                          console.warn("About image failed to load, reverting to fallback.");
                          setImageSrc("https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=1000");
                        }}
                    />
                    
                    {/* Upload Button Overlay */}
                    <label className="absolute bottom-4 right-4 bg-white/90 p-3 rounded-full cursor-pointer shadow-lg hover:bg-white text-brand-dark hover:text-brand-sageDark transition-all z-20" title="Change Image">
                        <input 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleImageUpload}
                        />
                        <Camera size={24} />
                    </label>
                </div>
             </div>
           </div>

           {/* Content */}
           <div className="w-full lg:w-1/2 space-y-6">
             <h2 className="font-serif text-4xl font-bold text-brand-dark">
                Hi, I'm {OWNER_NAME}.
             </h2>
             <h3 className="text-xl text-brand-sageDark font-bold">{OWNER_ROLE} & Strategic Partner</h3>
             
             <div className="space-y-4 text-slate-800 font-medium leading-relaxed">
                <p>
                    I understand the anxiety that comes with making big business decisions based on gut feelings. My journey began when I realized that most businesses aren't struggling from a lack of data, but from a lack of *translation*.
                </p>
                <p>
                    I combine technical precision (Python, SQL) with visual storytelling (Power BI) to create tools that don't just sit in your inbox—they drive your meetings.
                </p>
                <p>
                    Whether you are a startup needing your first dashboard or an enterprise needing complex predictive modeling, I treat your data with the care and confidentiality it deserves.
                </p>
             </div>

             <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6">
                {['Certified Power BI Expert', 'Python for Data Science', 'Statistical Analysis', 'Business Intelligence', 'Data Cleaning Specialist', 'Custom Reporting'].map((skill) => (
                    <div 
                        key={skill} 
                        className="flex items-center gap-2 text-brand-dark font-bold p-3 rounded-lg hover:bg-brand-cream hover:shadow-md hover:-translate-y-1 transition-all duration-300 cursor-default group"
                    >
                        <CheckCircle2 size={18} className="text-brand-sageDark group-hover:scale-110 transition-transform duration-300" />
                        <span>{skill}</span>
                    </div>
                ))}
             </div>
           </div>

        </div>
      </div>
    </section>
  );
};

export default About;