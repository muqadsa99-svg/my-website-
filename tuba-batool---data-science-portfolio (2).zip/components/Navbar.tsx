import React, { useState, useEffect } from 'react';
import { Menu, X, BarChart3, ExternalLink } from 'lucide-react';
import { NAV_LINKS, OWNER_NAME } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, link: { href: string, isExternal?: boolean }) => {
    // If it's an external link, let the browser handle it normally
    if (link.isExternal) return;

    // Prevent default anchor jump to allow for smooth scrolling
    e.preventDefault();
    setIsOpen(false);

    const targetId = link.href.replace('#', '');
    const element = document.getElementById(targetId);

    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      // Update the URL hash without jumping
      window.history.pushState(null, '', link.href);
    } else if (link.href === '#home') {
      // Fallback for home if ID isn't found (though it should be)
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-brand-cream/95 backdrop-blur-md shadow-sm py-2' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-brand-dark text-brand-cream p-2 rounded-full">
              <BarChart3 size={24} />
            </div>
            <a 
              href="#home" 
              onClick={(e) => handleLinkClick(e, { href: '#home' })}
              className="font-serif text-2xl font-bold tracking-tight text-brand-dark hover:text-brand-sageDark transition-colors"
            >
              {OWNER_NAME}
            </a>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8 items-center">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link)}
                target={link.isExternal ? "_blank" : undefined}
                rel={link.isExternal ? "noopener noreferrer" : undefined}
                className={`font-bold transition-all duration-200 flex items-center gap-1 cursor-pointer ${
                    link.isExternal 
                    ? 'px-4 py-2 bg-brand-dark text-white rounded-lg hover:bg-brand-sageDark shadow-md hover:shadow-lg' 
                    : 'text-brand-dark hover:text-brand-sageDark'
                }`}
              >
                {link.label}
                {link.isExternal && <ExternalLink size={14} />}
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-brand-dark hover:text-brand-sageDark transition-colors"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-brand-cream border-t border-brand-sageLight shadow-lg">
          <div className="flex flex-col px-4 py-6 space-y-4">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link)}
                target={link.isExternal ? "_blank" : undefined}
                rel={link.isExternal ? "noopener noreferrer" : undefined}
                className={`text-lg font-bold flex items-center gap-2 cursor-pointer ${
                    link.isExternal 
                    ? 'text-brand-sageDark' 
                    : 'text-brand-dark hover:text-brand-sageDark'
                }`}
              >
                {link.label}
                {link.isExternal && <ExternalLink size={16} />}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;