import React, { useState } from 'react';
import { ArrowRight, Camera, AlertTriangle } from 'lucide-react';
import { OWNER_NAME, OWNER_ROLE, UPWORK_URL, HERO_IMAGE } from '../constants';

interface HeroProps {
  imageSrc: string;
  setImageSrc: (src: string) => void;
}

const Hero: React.FC<HeroProps> = ({ imageSrc, setImageSrc }) => {
  const [loadError, setLoadError] = useState(false);
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_WIDTH = 800;
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
            setImageSrc(dataUrl);
            setLoadError(false);
          }
        };
        if (event.target?.result) {
          img.src = event.target.result as string;
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-brand-sageLight/30 -z-10 rounded-l-[100px]" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="space-y-8 animate-fade-in-up">
            <div className="inline-block px-4 py-1.5 rounded-full bg-brand-sage/20 text-brand-dark font-bold text-sm tracking-wider uppercase border border-brand-sage/30">
              {OWNER_ROLE}
            </div>
            <h1 className="font-serif text-5xl lg:text-6xl font-bold leading-tight text-brand-dark">
              Turn Your Data Chaos into <span className="text-brand-sageDark relative">
                Clarity
                <svg className="absolute w-full h-3 -bottom-1 left-0 text-brand-sage/40" viewBox="0 0 100 10" preserveAspectRatio="none">
                  <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="3" fill="none" />
                </svg>
              </span>
            </h1>
            <p className="text-lg text-slate-700 max-w-lg leading-relaxed font-medium">
              You’re sitting on a goldmine of data, but extracting the value feels like finding a needle in a haystack. I bridge the gap between complex raw data and clear, profitable business decisions using Power BI and Python.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href={UPWORK_URL}
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center px-8 py-4 bg-brand-dark text-white rounded-lg hover:bg-brand-sageDark transition-all duration-300 shadow-lg hover:shadow-xl font-bold"
              >
                Start Your Transformation
                <ArrowRight className="ml-2 w-5 h-5" />
              </a>
              <a href="#portfolio" className="inline-flex items-center justify-center px-8 py-4 border-2 border-brand-dark text-brand-dark rounded-lg hover:bg-brand-sageLight transition-all duration-300 font-bold">
                View Portfolio
              </a>
            </div>
          </div>

          <div className="relative group">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-8 border-white aspect-[4/5] lg:aspect-square mx-auto max-w-md lg:max-w-full bg-slate-100">
              <img 
                src={imageSrc} 
                alt={`${OWNER_NAME}`} 
                className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
                onError={() => {
                  if (imageSrc !== 'm1.png') {
                    setLoadError(true);
                    setImageSrc('m1.png');
                  }
                }}
              />
              
              <label className="absolute bottom-4 right-4 bg-white/90 p-3 rounded-full cursor-pointer shadow-lg hover:bg-white text-brand-dark hover:text-brand-sageDark transition-all z-20" title="Change Image">
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleImageUpload}
                />
                <Camera size={24} />
              </label>
            </div>
            
            {loadError && (
               <div className="absolute top-4 left-4 right-4 bg-amber-50 border border-amber-200 text-amber-800 px-4 py-2 rounded-lg text-xs flex items-center gap-2 z-30 shadow-sm">
                 <AlertTriangle size={14} />
                 <span>Could not find {imageSrc}. Using default.</span>
               </div>
            )}
            
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-xl max-w-xs hidden sm:block border-l-4 border-brand-sageDark z-10">
              <p className="font-serif text-lg text-brand-dark italic">"Data without insights is just noise."</p>
              <p className="text-sm text-slate-600 mt-2 font-bold">- {OWNER_NAME}</p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;