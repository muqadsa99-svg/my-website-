import React from 'react';
import { OWNER_NAME } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-dark text-brand-cream border-t border-white/10 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <span className="font-serif font-bold text-xl">{OWNER_NAME}</span>
          <span className="ml-2 text-brand-sageLight text-sm">| Data Scientist</span>
        </div>
        <div className="text-sm text-brand-sageLight">
          &copy; {new Date().getFullYear()} {OWNER_NAME}. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;