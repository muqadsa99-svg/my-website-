// CENTRALIZED CONTENT CONFIGURATION
export const OWNER_NAME = "Tuba Batool";
export const OWNER_ROLE = "Data Scientist & Power BI Expert";
export const UPWORK_URL = "https://www.upwork.com/ab/flservices/contracts/";

// CONTACT INFO
export const CONTACT_EMAIL = "tubabatool@gmail.com";
export const LINKEDIN_URL = "https://www.linkedin.com/in/tubabatool";

// IMAGES
// Use m1.png as the default hero image
export const HERO_IMAGE = "m1.png"; 
export const ABOUT_IMAGE = "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=1000";

// VIDEO
export const PORTFOLIO_VIDEO = "https://drive.google.com/file/d/1gRZnRicl8UXiw1XuTYNN7AXt4rjPtkpq/preview";

export const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'Portfolio', href: '#portfolio' },
  { label: 'About Me', href: '#about' },
  { label: 'Contact', href: '#contact' },
  { label: 'Hire Me', href: UPWORK_URL, isExternal: true },
];